Notes on the PDFlib C++ binding
-------------------------------

Supported compiler/linker versions for all supported platforms are
listed in system-requirements.txt.
